"use strict";
/*You can use strict mode in all your programs. It helps you to write cleaner code, like preventing you from using undeclared variables. - w3schools*/

$(document).ready(function(){
   $('h1').hide().fadeIn();
});



/* Lab 10 Task 3 */
/*
//checkUsername() – jQuery version
$(
function(){
	$('_________')._________(function(){
		if ($('_________').val().length< 6) {
			$('_________').removeClass('tip');
			$('_________').addClass('warning');
			$('_________').text('too short..');
		}
		else
		{
			$('_________').text('');
		}
	});
}
);
//tipUsername - jQuery version
$(
function(){
	$('_________')._________(function(){
		$('_________').addClass('tip');
		$('_________').text('Username must be at least 6 characters');
	});
}
);
*/
